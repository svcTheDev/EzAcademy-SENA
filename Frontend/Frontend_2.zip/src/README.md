

# EZACADEMY 

## Development pasos

1. Renombrar el archivo .env.template por .env
2. Hacer los cambios respectivos en las variables de entorno

```
VITE_API_URL=http://localhost:5000/api

```